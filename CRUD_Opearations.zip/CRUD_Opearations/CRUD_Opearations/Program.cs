﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace CRUD_Opearations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            connect();
            Insert1();
            Employee obj = new Employee { EmpNo = 7, Name = "vikram", Basic = 145789, DeptNo = 2 };
            Insert2(obj);
            Insert3(obj);
            selectsinglevalue();
            datareader2();
            MARS();
            CallFuncReturningSqlDataReader();
            datareader();
        }

        static void connect()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

            try
            {
                cn.Open();
                Console.WriteLine("Success");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }


        static void Insert1()
        {
            SqlConnection cn
                = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = CommandType.Text;
                cmdInsert.CommandText = "insert into Employees values(4,'Amol',157897,3)";
                cmdInsert.ExecuteNonQuery();

                Console.WriteLine("Success");

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        static void Insert2(Employee obj)
        {
            SqlConnection cn = new SqlConnection();

            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = CommandType.Text;
                cmdInsert.CommandText = $"insert into Employees Values({obj.EmpNo},'{obj.Name}',{obj.Basic},{obj.DeptNo})";

                Console.WriteLine(cmdInsert.CommandText);
                Console.ReadLine();
                cmdInsert.ExecuteNonQuery();

                Console.WriteLine("success");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        static void Insert3(Employee obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = CommandType.Text;
                cmdInsert.CommandText = $"insert into Employees Values(@EmpNo,@Name,@Basic,@DeptNo)";

                cmdInsert.Parameters.AddWithValue("@EmpNo", obj.EmpNo);
                cmdInsert.Parameters.AddWithValue("@Name", obj.Name);
                cmdInsert.Parameters.AddWithValue("@Basic", obj.Basic);
                cmdInsert.Parameters.AddWithValue("@DeptNo", obj.DeptNo);


                cmdInsert.ExecuteNonQuery();

                Console.WriteLine("success");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }


        static void selectsinglevalue()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";

            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select Name from Employees where EmpNo=2";

                object retval = cmd.ExecuteScalar();
                Console.WriteLine(retval);
                Console.WriteLine("success");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }


        static void datareader()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select *from Employees";

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    //Console.WriteLine(dr[3]);// this is index based opewartion 
                    //Console.WriteLine(dr["Name"]);

                    Employee o = new Employee();

                    o.Name = dr.GetString("Name");
                    Console.WriteLine(o.Name);

                }

                dr.Close();
                Console.WriteLine("success");

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        static void datareader2()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select *from Employees;select *from Department";

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    //Console.WriteLine(dr[3]);// this is index based opewartion 
                    //Console.WriteLine(dr["Name"]);

                    Employee o = new Employee();

                    o.Name = dr.GetString("Name");
                    Console.WriteLine(o.Name);

                }
                Console.WriteLine();
                dr.NextResult();
                while (dr.Read())
                {
                    Console.WriteLine(dr["DeptName"]);
                }

                dr.Close();
                Console.WriteLine("success");

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        //// static Employee GetSingleResult(int EmpNo)
        // {
        //     Employee emp = new Employee();

        // }

        static List<Employee> GetallEmployees()
        {
            List<Employee> list = new List<Employee>();



            return list;
        }

        static void MARS()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            cn.Open();

            SqlCommand cmdDepts = new SqlCommand();
            cmdDepts.Connection = cn;
            cmdDepts.CommandType = CommandType.Text;
            cmdDepts.CommandText = "select *from Department";

            SqlCommand cmdEmps = new SqlCommand();
            cmdEmps.Connection = cn;
            cmdEmps.CommandType = CommandType.Text;  // commandType=property  

            SqlDataReader drDepts = cmdDepts.ExecuteReader();
            while (drDepts.Read())
            {
                Console.WriteLine((drDepts["DeptName"]));

                cmdEmps.CommandText = "select * from Employees where DeptNo = " + drDepts["DeptNo"];
                SqlDataReader drEmps = cmdEmps.ExecuteReader();

                while (drEmps.Read())
                {
                    Console.WriteLine(("     " + drEmps["Name"]));

                }
                drEmps.Close();
            }
            drDepts.Close();
            cn.Close();
        }

        static void CallFuncReturningSqlDataReader()
        {
            SqlDataReader dr = GetDataReader();
            while (dr.Read())
            {
                Console.WriteLine(dr[2]);
            }
        }

        static SqlDataReader GetDataReader()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ActsDec2023;Integrated Security=True;";
            cn.Open();
            SqlCommand cmdInsert = new SqlCommand();
            cmdInsert.Connection = cn;
            cmdInsert.CommandType = System.Data.CommandType.Text; // commandType= Property
            cmdInsert.CommandText = "select * from Employees";  //commandtext= Property
            SqlDataReader dr = cmdInsert.ExecuteReader();
            //SqlDataReader dr = cmdInsert.ExecuteReader(CommandBehavior.CloseConnection);//no need to close conn it will closes when data reader closes
            cn.Close();
            return dr;

        }



        internal class Employee
        {
            private int empNo;
            public int EmpNo { get; set; }

            private string name;
            public string Name { get; set; }

            private decimal basic;
            public decimal Basic { get; set; }

            private int deptNo;
            public int DeptNo { get; set; }

            //public Employee(int EmpNo, string Name, decimal Basic, int DeptNo)
            //{
            //    this.empNo = EmpNo;     
            //    this.name = Name;
            //    this.basic = Basic;               
            //    this.deptNo = DeptNo;
            //}


        }


    }
}